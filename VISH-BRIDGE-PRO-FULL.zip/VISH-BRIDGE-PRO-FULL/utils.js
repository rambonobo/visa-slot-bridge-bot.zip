import pino from 'pino';

const level = process.env.LOG_LEVEL || 'error'; // keep quiet by default
export const log = pino({ level });

export function mustGet(name) {
  const v = process.env[name];
  if (!v) throw new Error(`Missing ${name} in environment.`);
  return v;
}

export function optional(name, def='') {
  const v = process.env[name];
  return (v === undefined || v === null) ? def : v;
}

export function isTextMessage(msg) {
  // Telegram message: accept only pure text
  return Boolean(msg.text) && !msg.photo && !msg.document && !msg.video && !msg.audio && !msg.sticker && !msg.voice;
}

export function clean(text='') {
  // basic cleaning: collapse spaces
  return String(text).replace(/[\t ]+/g, ' ').trim();
}
