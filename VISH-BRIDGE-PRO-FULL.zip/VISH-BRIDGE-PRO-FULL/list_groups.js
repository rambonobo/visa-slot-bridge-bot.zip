import { initWhatsApp } from './whatsapp.js';
import { log } from './utils.js';

(async () => {
  const sock = await initWhatsApp();
  const groups = await sock.groupFetchAllParticipating();
  for (const [jid, info] of Object.entries(groups)) {
    log.info({ name: info.subject, jid }, `WA Group -> ${info.subject} :: ${jid}`);
  }
  process.exit(0);
})().catch(err => { console.error(err); process.exit(1); });
