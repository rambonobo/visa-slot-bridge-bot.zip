# VISH BRIDGE PRO (Telegram Topic -> WhatsApp Group, text-only)

## Quick start (Railway)
1) Create a new service from this repo/zip.
2) Set these Railway Variables (copy from .env):
   - TELEGRAM_TOKEN
   - H_CHAT_ID, H_TOPIC_ID
   - F_CHAT_ID, F_TOPIC_ID
   - B_CHAT_ID, B_TOPIC_BUPDATES_ID, B_TOPIC_CANADA_ID
   - WA_H_GROUP, WA_F_GROUP, WA_B_UPDATES_GROUP, WA_B_CANADA_GROUP  (WhatsApp group JIDs)
3) Deploy. Logs will be quiet (errors only).

### Get WhatsApp group IDs (JIDs)
If you don't know the JIDs yet, run once locally:
```
npm i
npm run list:wa
```
You'll see lines like `WA Group -> My Group :: 1203630...-123456@g.us`. Put that value into the WA_* envs (including @g.us).

### Notes
- Only messages inside the specified Telegram **topic IDs** are forwarded.
- Only **text** is forwarded; media/stickers are ignored.
- Uses Baileys multi-file auth in `./auth_whatsapp/`. Place your session files here to skip QR.
