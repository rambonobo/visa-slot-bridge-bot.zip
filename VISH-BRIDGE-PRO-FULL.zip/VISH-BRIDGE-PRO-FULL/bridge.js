import 'dotenv/config';
import TelegramBot from 'node-telegram-bot-api';
import { initWhatsApp } from './whatsapp.js';
import { log, mustGet, optional, isTextMessage, clean } from './utils.js';

// --- Required env
const TELEGRAM_TOKEN = mustGet('TELEGRAM_TOKEN');

// Telegram filters (listen only to these chat+topic pairs)
const MAP = [
  { chatId: Number(mustGet('H_CHAT_ID')), topicId: Number(mustGet('H_TOPIC_ID')), wa: optional('WA_H_GROUP') },
  { chatId: Number(mustGet('F_CHAT_ID')), topicId: Number(mustGet('F_TOPIC_ID')), wa: optional('WA_F_GROUP') },
  { chatId: Number(mustGet('B_CHAT_ID')), topicId: Number(mustGet('B_TOPIC_BUPDATES_ID')), wa: optional('WA_B_UPDATES_GROUP') },
  { chatId: Number(mustGet('B_CHAT_ID')), topicId: Number(mustGet('B_TOPIC_CANADA_ID')), wa: optional('WA_B_CANADA_GROUP') },
];

function findTarget(chatId, threadId) {
  return MAP.find(m => m.chatId === chatId && m.topicId === threadId && m.wa);
}

(async () => {
  const bot = new TelegramBot(TELEGRAM_TOKEN, { polling: true });
  const wa = await initWhatsApp();

  bot.on('message', async (msg) => {
    try {
      // Only forward messages that are inside a forum topic we mapped
      const chatId = msg.chat?.id;
      const threadId = msg.message_thread_id;
      if (!chatId || !threadId) return; // ignore messages outside topics
      const target = findTarget(chatId, threadId);
      if (!target) return; // not a mapped topic

      if (!isTextMessage(msg)) return; // only pure text

      const text = clean(msg.text || '');
      if (!text) return;
      const jid = target.wa;
      if (!jid) {
        log.warn({ chatId, threadId }, 'WA group JID missing for this topic.');
        return;
      }
      // Ensure the JID ends with @g.us (WhatsApp group)
      const groupJid = jid.endsWith('@g.us') ? jid : `${jid}@g.us`;
      await wa.sendMessage(groupJid, { text });

    } catch (e) {
      log.error(e, 'forwarding failed');
    }
  });

  log.info('🚀 Bridge running (Telegram -> WhatsApp).');
})().catch(err => {
  log.error(err, 'fatal');
  process.exit(1);
});
